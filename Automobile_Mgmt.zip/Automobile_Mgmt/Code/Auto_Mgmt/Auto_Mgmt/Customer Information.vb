﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Customer_Information
    Dim gender As String
    Dim email1 As String
    'MAX ID
    Public Sub MaxID()
        Dim cid As Integer
        strsql = "select MAX(cid) From CustReg"
        Connection()
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            While dr.Read
                If dr(0).ToString = "" Then
                    txtcid.Text = "1"
                Else
                    cid = dr(0).ToString
                    txtcid.Text = cid + 1
                End If
            End While
        End If
        Conclose()
    End Sub
    'Clear Code
    Public Sub Clear()
        txtcid.Text = ""
        txtcname.Text = ""
        txtcadd.Text = ""
        txtcmob.Text = ""
        '  gender = ""
        rbtmale.Checked = False
        rbtfemale.Checked = False
        txtemail.Text = ""
        cbemail.Text = ""

    End Sub

    'Registration Code
    Private Sub btnreg_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreg.Click
        If txtcid.Text = "" Then
            MsgBox("User ID Not Generated")
            txtcid.Focus()
            'btnreg.BackColor = Color.Red
            Exit Sub
        End If
        If txtcname.Text = "" Then
            MsgBox("User Name")
            txtcname.Focus()
            Exit Sub
        End If

        If rbtmale.Checked = True Then
            gender = "Male"
        End If
        If rbtfemale.Checked = True Then
            gender = "Female"
        End If

        email1 = txtemail.Text & cbemail.Text
        strsql = "Insert into CustReg(cid,cname,cadd,cmob,regdate,cgender,cemail) values(" & txtcid.Text & ",'" & txtcname.Text & " ','" & txtcadd.Text & "','" & txtcmob.Text & "','" & datetimepicker1.Value & "', '" & gender & "','" & email1 & "' )"
        Connection()
        cmd = New SqlCommand(strsql, con)
        cmd.ExecuteNonQuery()
        Conclose()
        MsgBox("Record Added Successfully")
        Clear()
        MaxID()
        btnreg.Enabled = False
    End Sub

    'Close Button Code
    Private Sub btncancle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btncancle.Click
        Me.Close()
    End Sub

    Private Sub Customer_Information_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MaxID()
        txtcid.Enabled = False
    End Sub
End Class