﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Auto_Mob_Shop
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.Usermainmenu = New System.Windows.Forms.ToolStripMenuItem
        Me.RegisterUserInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.UpdateUserInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteUserInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.RegisterCustomerInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.UpdateCustomerInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteCustomerInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.SearchCustomerInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.AutoPartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddAutoPartInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.UpdateAutoPartInfo = New System.Windows.Forms.ToolStripMenuItem
        Me.DeleteAutoPart = New System.Windows.Forms.ToolStripMenuItem
        Me.SearchAutoPart = New System.Windows.Forms.ToolStripMenuItem
        Me.StockToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AddStock = New System.Windows.Forms.ToolStripMenuItem
        Me.StockSearch = New System.Windows.Forms.ToolStripMenuItem
        Me.SaleFormToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaleDetailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CustomerInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.AutoPartInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StockReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.SaleReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.Usermainmenu, Me.CustomerToolStripMenuItem, Me.AutoPartToolStripMenuItem, Me.StockToolStripMenuItem, Me.SaleFormToolStripMenuItem, Me.ReportToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(8, 3, 0, 3)
        Me.MenuStrip1.Size = New System.Drawing.Size(858, 32)
        Me.MenuStrip1.TabIndex = 1
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'Usermainmenu
        '
        Me.Usermainmenu.BackColor = System.Drawing.Color.White
        Me.Usermainmenu.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegisterUserInfo, Me.UpdateUserInfo, Me.DeleteUserInfo})
        Me.Usermainmenu.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Usermainmenu.Name = "Usermainmenu"
        Me.Usermainmenu.Size = New System.Drawing.Size(59, 26)
        Me.Usermainmenu.Text = "User"
        '
        'RegisterUserInfo
        '
        Me.RegisterUserInfo.Name = "RegisterUserInfo"
        Me.RegisterUserInfo.Size = New System.Drawing.Size(188, 26)
        Me.RegisterUserInfo.Text = "User Register"
        '
        'UpdateUserInfo
        '
        Me.UpdateUserInfo.Name = "UpdateUserInfo"
        Me.UpdateUserInfo.Size = New System.Drawing.Size(188, 26)
        Me.UpdateUserInfo.Text = "User Update"
        '
        'DeleteUserInfo
        '
        Me.DeleteUserInfo.Name = "DeleteUserInfo"
        Me.DeleteUserInfo.Size = New System.Drawing.Size(188, 26)
        Me.DeleteUserInfo.Text = "User Delete"
        '
        'CustomerToolStripMenuItem
        '
        Me.CustomerToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.CustomerToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegisterCustomerInfo, Me.UpdateCustomerInfo, Me.DeleteCustomerInfo, Me.SearchCustomerInfo})
        Me.CustomerToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CustomerToolStripMenuItem.Name = "CustomerToolStripMenuItem"
        Me.CustomerToolStripMenuItem.Size = New System.Drawing.Size(97, 26)
        Me.CustomerToolStripMenuItem.Text = "Customer"
        '
        'RegisterCustomerInfo
        '
        Me.RegisterCustomerInfo.Name = "RegisterCustomerInfo"
        Me.RegisterCustomerInfo.Size = New System.Drawing.Size(186, 26)
        Me.RegisterCustomerInfo.Text = "Cust Register"
        '
        'UpdateCustomerInfo
        '
        Me.UpdateCustomerInfo.Name = "UpdateCustomerInfo"
        Me.UpdateCustomerInfo.Size = New System.Drawing.Size(186, 26)
        Me.UpdateCustomerInfo.Text = "Cust Update"
        '
        'DeleteCustomerInfo
        '
        Me.DeleteCustomerInfo.Name = "DeleteCustomerInfo"
        Me.DeleteCustomerInfo.Size = New System.Drawing.Size(186, 26)
        Me.DeleteCustomerInfo.Text = "Delete"
        '
        'SearchCustomerInfo
        '
        Me.SearchCustomerInfo.Name = "SearchCustomerInfo"
        Me.SearchCustomerInfo.Size = New System.Drawing.Size(186, 26)
        Me.SearchCustomerInfo.Text = "Search"
        '
        'AutoPartToolStripMenuItem
        '
        Me.AutoPartToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.AutoPartToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddAutoPartInfo, Me.UpdateAutoPartInfo, Me.DeleteAutoPart, Me.SearchAutoPart})
        Me.AutoPartToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AutoPartToolStripMenuItem.Name = "AutoPartToolStripMenuItem"
        Me.AutoPartToolStripMenuItem.Size = New System.Drawing.Size(97, 26)
        Me.AutoPartToolStripMenuItem.Text = "Auto Part"
        '
        'AddAutoPartInfo
        '
        Me.AddAutoPartInfo.Name = "AddAutoPartInfo"
        Me.AddAutoPartInfo.Size = New System.Drawing.Size(152, 26)
        Me.AddAutoPartInfo.Text = "Add"
        '
        'UpdateAutoPartInfo
        '
        Me.UpdateAutoPartInfo.Name = "UpdateAutoPartInfo"
        Me.UpdateAutoPartInfo.Size = New System.Drawing.Size(152, 26)
        Me.UpdateAutoPartInfo.Text = "Update"
        '
        'DeleteAutoPart
        '
        Me.DeleteAutoPart.Name = "DeleteAutoPart"
        Me.DeleteAutoPart.Size = New System.Drawing.Size(152, 26)
        Me.DeleteAutoPart.Text = "Delete"
        '
        'SearchAutoPart
        '
        Me.SearchAutoPart.Name = "SearchAutoPart"
        Me.SearchAutoPart.Size = New System.Drawing.Size(152, 26)
        Me.SearchAutoPart.Text = "Search"
        '
        'StockToolStripMenuItem
        '
        Me.StockToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.StockToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddStock, Me.StockSearch})
        Me.StockToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StockToolStripMenuItem.Name = "StockToolStripMenuItem"
        Me.StockToolStripMenuItem.Size = New System.Drawing.Size(66, 26)
        Me.StockToolStripMenuItem.Text = "Stock"
        '
        'AddStock
        '
        Me.AddStock.Name = "AddStock"
        Me.AddStock.Size = New System.Drawing.Size(183, 26)
        Me.AddStock.Text = "Stock Add"
        '
        'StockSearch
        '
        Me.StockSearch.Name = "StockSearch"
        Me.StockSearch.Size = New System.Drawing.Size(183, 26)
        Me.StockSearch.Text = "Stock Search"
        '
        'SaleFormToolStripMenuItem
        '
        Me.SaleFormToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.SaleFormToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SaleDetailToolStripMenuItem})
        Me.SaleFormToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SaleFormToolStripMenuItem.Name = "SaleFormToolStripMenuItem"
        Me.SaleFormToolStripMenuItem.Size = New System.Drawing.Size(104, 26)
        Me.SaleFormToolStripMenuItem.Text = "Sale Form"
        '
        'SaleDetailToolStripMenuItem
        '
        Me.SaleDetailToolStripMenuItem.Name = "SaleDetailToolStripMenuItem"
        Me.SaleDetailToolStripMenuItem.Size = New System.Drawing.Size(169, 26)
        Me.SaleDetailToolStripMenuItem.Text = "Sale Detail"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.BackColor = System.Drawing.Color.White
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CustomerInfoToolStripMenuItem, Me.AutoPartInfoToolStripMenuItem, Me.StockReportToolStripMenuItem, Me.SaleReportToolStripMenuItem})
        Me.ReportToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(76, 26)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'CustomerInfoToolStripMenuItem
        '
        Me.CustomerInfoToolStripMenuItem.Name = "CustomerInfoToolStripMenuItem"
        Me.CustomerInfoToolStripMenuItem.Size = New System.Drawing.Size(214, 26)
        Me.CustomerInfoToolStripMenuItem.Text = "Customer Report"
        '
        'AutoPartInfoToolStripMenuItem
        '
        Me.AutoPartInfoToolStripMenuItem.Name = "AutoPartInfoToolStripMenuItem"
        Me.AutoPartInfoToolStripMenuItem.Size = New System.Drawing.Size(214, 26)
        Me.AutoPartInfoToolStripMenuItem.Text = "Auto Part Report"
        '
        'StockReportToolStripMenuItem
        '
        Me.StockReportToolStripMenuItem.Name = "StockReportToolStripMenuItem"
        Me.StockReportToolStripMenuItem.Size = New System.Drawing.Size(214, 26)
        Me.StockReportToolStripMenuItem.Text = "Stock Report"
        '
        'SaleReportToolStripMenuItem
        '
        Me.SaleReportToolStripMenuItem.Name = "SaleReportToolStripMenuItem"
        Me.SaleReportToolStripMenuItem.Size = New System.Drawing.Size(214, 26)
        Me.SaleReportToolStripMenuItem.Text = "Sale Report"
        '
        'Auto_Mob_Shop
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 22.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Auto_Mgmt.My.Resources.Resources.d7d1f3a122fa1930b2de5c409aa1abe8
        Me.ClientSize = New System.Drawing.Size(858, 471)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Auto_Mob_Shop"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Auto_Mob_Shop"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Usermainmenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegisterUserInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateUserInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteUserInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegisterCustomerInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateCustomerInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteCustomerInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchCustomerInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoPartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddAutoPartInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateAutoPartInfo As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DeleteAutoPart As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchAutoPart As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddStock As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockSearch As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaleFormToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CustomerInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AutoPartInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaleDetailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StockReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SaleReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
