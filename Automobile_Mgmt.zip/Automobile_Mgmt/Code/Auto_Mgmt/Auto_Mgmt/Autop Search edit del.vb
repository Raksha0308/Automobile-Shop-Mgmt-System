﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Aotop_Search_edit_del
    'FILL DATAGRID
    Public Sub Grid_Fill()
        Connection()
        strsql = "select pid As Part_ID,pname As Part_Name,ptype As Type,company As Company,rate As Rate,adesc As Description from AutopInfo"
        cmd = New SqlCommand(strsql, con)
        cmd.CommandType = CommandType.Text
        da = New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        Conclose()
    End Sub
    'clear code
    Public Sub Clear()
        cbpid.Text = ""
        txtpname.Text = ""
        txtcompany.Text = ""
        txtadesc.Text = ""
        cbpid1.Text = ""
    End Sub

    Private Sub Aotop_Search_edit_del_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Grid_Fill()
        'ACCESS ID
        Connection()
        strsql = "select  pid from AutopInfo"
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If (dr.HasRows) Then
            While (dr.Read)
                cbpid.Items.Add(dr(0).ToString())
                cbpid1.Items.Add(dr(0).ToString())
                cbsearchid.Items.Add(dr(0).ToString())
            End While
        End If
        Conclose()

        If mid = 0 Then
            lbldel1.Visible = False
            lblsearch.Visible = False
            btndel.Visible = False
            btnexit1.Visible = False
            lbldel.Visible = False
            cbpid1.Visible = False
            lblsearchid.Visible = False
            cbsearchid.Visible = False
            lbl_s_name.Visible = False
            txt_s_name.Visible = False
        End If
        If mid = 1 Then
            lblupdate.Visible = False
            lblsearch.Visible = False
            btnupdate.Visible = False
            btnexit.Visible = False
            lbldel.Visible = True
            cbpid1.Visible = True
            lblsearchid.Visible = False
            cbsearchid.Visible = False
            lbl_s_name.Visible = False
            txt_s_name.Visible = False
            lblupdate.Visible = False
            lblpid.Visible = False
            lblpname.Visible = False
            lblcompany.Visible = False
            lbladesc.Visible = False
            cbpid.Visible = False
            txtpname.Visible = False
            txtcompany.Visible = False
            txtadesc.Visible = False
        End If
        If mid = 2 Then

            lbldel1.Visible = False
            lblupdate.Visible = False
            lblpid.Visible = False
            lblpname.Visible = False
            lblcompany.Visible = False
            lbladesc.Visible = False
            cbpid.Visible = False
            txtpname.Visible = False
            txtcompany.Visible = False
            txtadesc.Visible = False
            btnupdate.Visible = False
            btnexit.Visible = False
            lbldel.Visible = False
            cbpid1.Visible = False
            btndel.Visible = False
            btnexit1.Visible = False
        End If

    End Sub

    'FORM CLOSE
    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub
    'AUTO INFO DELETE
    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
        If cbpid1.Text <> "" And IsNumeric(cbpid1.Text) Then
            Connection()
            strsql = "Delete from AutopInfo Where pid=" & cbpid1.Text
            cmd = New SqlCommand(strsql, con)
            cmd.ExecuteNonQuery()
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            MsgBox("Automobile Information Removed")
            Conclose()
        Else
            MsgBox("Select ID")
            Grid_Fill()
            Clear()
        End If

    End Sub
    'UPDATE AUTO INFO
    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        If cbpid.Text <> "" And IsNumeric(cbpid.Text) Then
            Connection()
            strsql = "update AutopInfo set pname= '" & txtpname.Text & " ',company= '" & txtcompany.Text & "',adesc='" & txtadesc.Text & "' where pid=" & cbpid.Text
            cmd = New SqlCommand(strsql, con)
            cmd.ExecuteNonQuery()
            MsgBox("Automobile Information Updated")
            Grid_Fill()
            Clear()
            Conclose()
        Else
            MsgBox("Select Auto Part Id")
        End If
    End Sub

    Private Sub cbpid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbpid.SelectedIndexChanged

        'search code
        If cbpid.Text <> "" And IsNumeric(cbpid.Text) Then
            Connection()
            strsql = "select * from AutopInfo where pid=" & cbpid.Text
            cmd = New SqlCommand(strsql, con)
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                While dr.Read
                    txtpname.Text = dr(1).ToString
                    txtcompany.Text = dr(3).ToString
                    txtadesc.Text = dr(5).ToString
                End While

            Else
                MsgBox("Customer id information is not available")
            End If
            Conclose()
        Else
            MsgBox("Select Customer Id")
            Exit Sub
        End If
    End Sub
    'SEARCH BY ID
    Private Sub cbpid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbpid1.SelectedIndexChanged
        If cbpid1.Text <> "" And IsNumeric(cbpid1.Text) Then
            Connection()
            strsql = "select pid,pname,ptype,company,rate,adesc from AutopInfo where pid=" & cbpid1.Text
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            Clear()
            Grid_Fill()
            Conclose()
        End If

    End Sub
    'EXIT FORM
    Private Sub btnexit1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit1.Click
        Me.Close()
    End Sub
    'SEARCH BY ID
    Private Sub cbsearchid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbsearchid.SelectedIndexChanged
        If cbsearchid.Text <> "" And IsNumeric(cbsearchid.Text) Then
            Connection()
            strsql = "select pid,pname,ptype,company,rate,adesc from AutopInfo where pid=" & cbsearchid.Text
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            Clear()
            Conclose()
        End If
    End Sub

    Private Sub txt_s_name_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles txt_s_name.GotFocus
        cbsearchid.Text = ""
        Grid_Fill()

    End Sub
    'SEARCH BY NAME
    Private Sub txt_s_name_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txt_s_name.TextChanged
        If txt_s_name.Text <> "" Then
            Connection()
            strsql = "select pid,pname,ptype,company,rate,adesc from AutopInfo where pname like '%" & txt_s_name.Text & "%'"
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            Conclose()
        Else
            Grid_Fill()
        End If
    End Sub

    Private Sub cbsearchid_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbsearchid.GotFocus
        txt_s_name.Text = ""
        Grid_Fill()
    End Sub

End Class



