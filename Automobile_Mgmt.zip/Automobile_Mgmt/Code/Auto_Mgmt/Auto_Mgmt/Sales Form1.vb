﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Sales_Form1
    Dim dt As DataTable
    Dim cb As SqlCommandBuilder
    Dim bs As BindingSource
    Public Sub GridFill()
        Connection()
        strsql = "select Sid,Apname,Aprate,Aqty,Atot from SaleView"
        cmd = New SqlCommand(strsql, con)
        cmd.CommandType = CommandType.Text
        da = New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        Conclose()
    End Sub
    Private Sub ComboFill()
        strsql = "select Cname from CustReg"
        Connection()
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            While dr.Read
                cbCname.Items.Add(dr(0).ToString)
            End While
        End If
        Conclose()
        strsql = "select Apname from Stock Where Aqty > 0 "
        Connection()
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            While dr.Read
                cbapname.Items.Add(dr(0).ToString)
            End While
        End If
        Conclose()
    End Sub
    Public Sub Total()
        If txttax.Text = "" Then
            txttax.Text = 0
        End If
        If txttax.Text <> "" Then
            Dim Dis As Double
            Dis = CDbl(txttax.Text)
            Dim tt As Double
            strsql = "select sum(Atot) from SaleView"
            Connection()
            cmd = New SqlCommand(strsql, con)
            dr = cmd.ExecuteReader()
            If dr.HasRows Then
                While dr.Read
                    tt = CDbl(dr(0).ToString)
                End While
                tt = tt + (tt * Dis \ 100)
                txttotal.Text = tt.ToString
                Conclose()
            End If
        Else
            MsgBox("Store Detail ")
        End If
    End Sub
    Private Sub Sales_Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txttax.Enabled = False
        strsql = "Delete from SaleView"
        Connection()
        cmd = New SqlCommand(strsql, con)
        cmd.ExecuteNonQuery()
        Conclose()
        txtsdate.Text = DateTimePicker1.Value
        Dim slid As Integer
        strsql = "Select MAX(Saleid) from SaleTab"
        Connection()
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            While dr.Read
                If dr(0).ToString = "" Then
                    txtsid.Text = "1001"
                Else
                    slid = dr(0).ToString
                    txtsid.Text = slid + 1
                End If
            End While
        End If
        ComboFill()
        'GridFill()
        txtsid.Enabled = False
        txtcmob.Enabled = False
        txtcid.Enabled = False
        txtapid.Enabled = False
        txtaprate.Enabled = False
        txtsdate.Enabled = False
    End Sub

    Private Sub cbcname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbcname.SelectedIndexChanged
        Connection()
        strsql = "select Cid,Cname,Cmob from CustReg where Cname='" & cbcname.Text & "'"
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader()
        While dr.Read
            txtcid.Text = dr(0).ToString
            txtcmob.Text = dr(2).ToString
        End While
        Conclose()

    End Sub

    Private Sub cbapname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbapname.SelectedIndexChanged
        Connection()
        strsql = "select Sid,pid,Aprate,Aqty from Stock where Apname='" & cbapname.Text & "' AND Aqty > 0"
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader()
        If dr.HasRows Then
            While dr.Read
                cbapname.Text = dr(0).ToString
                txtapid.Text = dr(1).ToString
                txtaprate.Text = dr(2).ToString
                'txtaqty.Text = dr(3).ToString
            End While
            Conclose()
        Else
            MsgBox("Rows Not Found")
        End If
    End Sub


    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        If txtaqty.Text <> "" And txtaprate.Text <> "" Then
            Dim mt As Integer
            mt = Integer.Parse(txtaqty.Text) * Integer.Parse(txtaprate.Text)
            strsql = "Insert Into SaleView(Sid,Apname,Aprate,Aqty,Atot) values(" & txtsid.Text & ",'" & cbapname.Text & "'," & txtaprate.Text & "," & txtaqty.Text & "," & mt & ") "
            Connection()
            cmd = New SqlCommand(strsql, con)
            cmd.ExecuteNonQuery()
            txttax.Enabled = True
            Conclose()
            GridFill()
            Total()
        End If
    End Sub

    Private Sub txttax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttax.TextChanged
        If txttax.Text <> "" Then
            Total()

        End If
    End Sub

   

    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub

    
    'Private Sub btnprintbill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
    '    strsql = "select Sid,Apname,Aprate,Aqty,Atot from SaleView"
    '    Dim str1 As String = ""
    '    Dim str2 As String = ""
    '    Connection()
    '    cmd = New SqlCommand(strsql, con)
    '    dr = cmd.ExecuteReader
    '    If dr.HasRows Then
    '        While dr.Read
    '            'str1 &= "Insert into SaleTab(Saleid,Sdate,Cid,Cname,Cmob,pid,Apname,Aprate,Aqty,Atot,Atax) values (" & txtsid.Text & ",'" & txtsdate.Text & "'," & txtcid.Text & ",'" & cbcname.Text & "','" & txtcmob.Text & "'," & dr(0).ToString & ",'" & dr(1).ToString & "'," & dr(2).ToString & "," & dr(3).ToString & "," & dr(4).ToString & "," & txttax.Text & ");"
    '            str1 &= "Insert into SaleTab(Saleid,Sdate,Cid,Cname,Cmob,pid,Apname,Aprate,Aqty,Atot,Atax) values(" & dr(0).ToString & ",'" & txtsdate.Text & "'," & txtcid.Text & ",'" & cbcname.Text & "','" & txtcmob.Text & "'," & txtapid.Text & ",'" & dr(1).ToString & "'," & dr(2).ToString & "," & dr(3).ToString & "," & dr(4).ToString & "," & txttax.Text & ");"
    '            'str2 &= "Update Stock set Aqty=Aqty - " & dr(3).ToString & " Where Sid=" & dr(0).ToString & ";"
    '            str2 &= "Update Stock set Aqty=Aqty - " & dr(3).ToString & " Where Sid=" & dr(0).ToString & ";"
    '        End While
    '    End If
    '    Conclose()
    '    Connection()
    '    cmd = New SqlCommand(str1, con)
    '    cmd.ExecuteNonQuery()
    '    MsgBox("Order Details Insert")
    '    Conclose()
    '    Connection()
    '    cmd = New SqlCommand(str2, con)
    '    cmd.ExecuteNonQuery()
    '    MsgBox("Order Details Minus")
    '    con.Close()
    '    Billno = txtsid.Text
    '    BillGenerate1.Show()
    'End Sub

    Private Sub PrintBill_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintBill.Click
        strsql = "select Sid,Apname,Aprate,Aqty,Atot from SaleView"
        Dim str1 As String = ""
        Dim str2 As String = ""
        Connection()
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If dr.HasRows Then
            While dr.Read
                'str1 &= "Insert into SaleTab(Saleid,Sdate,Cid,Cname,Cmob,pid,Apname,Aprate,Aqty,Atot,Atax) values (" & txtsid.Text & ",'" & txtsdate.Text & "'," & txtcid.Text & ",'" & cbcname.Text & "','" & txtcmob.Text & "'," & dr(0).ToString & ",'" & dr(1).ToString & "'," & dr(2).ToString & "," & dr(3).ToString & "," & dr(4).ToString & "," & txttax.Text & ");"
                str1 &= "Insert into SaleTab(Saleid,Sdate,Cid,Cname,Cmob,pid,Apname,Aprate,Aqty,Atot,Atax) values(" & dr(0).ToString & ",'" & txtsdate.Text & "'," & txtcid.Text & ",'" & cbcname.Text & "','" & txtcmob.Text & "'," & txtapid.Text & ",'" & dr(1).ToString & "'," & dr(2).ToString & "," & dr(3).ToString & "," & dr(4).ToString & "," & txttax.Text & ");"
                str2 &= "Update Stock set Aqty=Aqty - " & dr(3).ToString & " Where Sid=" & dr(0).ToString & ";"
            End While
        End If
        Conclose()
        Connection()
        cmd = New SqlCommand(str1, con)
        cmd.ExecuteNonQuery()
        MsgBox("Order Details Insert")
        Conclose()
        Connection()
        cmd = New SqlCommand(str2, con)
        cmd.ExecuteNonQuery()
        MsgBox("Order Details Minus")
        con.Close()
        Billno = txtsid.Text
        BillView.Show()
    End Sub
End Class