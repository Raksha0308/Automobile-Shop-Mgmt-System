﻿Imports CrystalDecisions.CrystalReports.Engine
Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.Shared
Public Class BillGenerate1
    Private Sub BillGenerate1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cryRpt As New ReportDocument
        cryRpt.Load("D:\Auto_Mgmt\Code\Auto_Mgmt\Auto_Mgmt\BillGenerate.rpt")
        Dim crs As ParameterFieldDefinitions
        Dim cr As ParameterFieldDefinition
        Dim Pr As New ParameterValues
        Dim Prd As New ParameterDiscreteValue
        Prd.Value = Billno
        crs = cryRpt.DataDefinition.ParameterFields
        cr = crs("@saleid")
        Pr = cr.CurrentValues
        Pr.Add(Prd)
        cr.ApplyCurrentValues(Pr)
        CrystalReportViewer1.ReportSource = cryRpt
        CrystalReportViewer1.Refresh()
    End Sub
End Class