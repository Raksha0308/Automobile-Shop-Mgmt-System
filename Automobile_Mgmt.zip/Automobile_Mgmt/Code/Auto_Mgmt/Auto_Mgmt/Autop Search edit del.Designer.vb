﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Aotop_Search_edit_del
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.lbladesc = New System.Windows.Forms.Label
        Me.lblpid = New System.Windows.Forms.Label
        Me.txtcompany = New System.Windows.Forms.TextBox
        Me.txtadesc = New System.Windows.Forms.TextBox
        Me.txtpname = New System.Windows.Forms.TextBox
        Me.lblcompany = New System.Windows.Forms.Label
        Me.lblpname = New System.Windows.Forms.Label
        Me.cbpid = New System.Windows.Forms.ComboBox
        Me.btnupdate = New System.Windows.Forms.Button
        Me.btnexit = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.lblsearchid = New System.Windows.Forms.Label
        Me.lbl_s_name = New System.Windows.Forms.Label
        Me.cbsearchid = New System.Windows.Forms.ComboBox
        Me.txt_s_name = New System.Windows.Forms.TextBox
        Me.btndel = New System.Windows.Forms.Button
        Me.btnexit1 = New System.Windows.Forms.Button
        Me.lbldel = New System.Windows.Forms.Label
        Me.cbpid1 = New System.Windows.Forms.ComboBox
        Me.lbldel1 = New System.Windows.Forms.Label
        Me.lblupdate = New System.Windows.Forms.Label
        Me.lblsearch = New System.Windows.Forms.Label
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Auto_Mgmt.My.Resources.Resources.backimg2
        Me.PictureBox1.Location = New System.Drawing.Point(-1, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(1301, 528)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lbladesc
        '
        Me.lbladesc.AutoSize = True
        Me.lbladesc.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbladesc.Location = New System.Drawing.Point(12, 175)
        Me.lbladesc.Name = "lbladesc"
        Me.lbladesc.Size = New System.Drawing.Size(133, 21)
        Me.lbladesc.TabIndex = 21
        Me.lbladesc.Text = "DESCRIPTION"
        '
        'lblpid
        '
        Me.lblpid.AutoSize = True
        Me.lblpid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpid.Location = New System.Drawing.Point(12, 69)
        Me.lblpid.Name = "lblpid"
        Me.lblpid.Size = New System.Drawing.Size(137, 21)
        Me.lblpid.TabIndex = 19
        Me.lblpid.Text = "AUTO PART ID"
        '
        'txtcompany
        '
        Me.txtcompany.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcompany.Location = New System.Drawing.Point(176, 138)
        Me.txtcompany.MaxLength = 10
        Me.txtcompany.Name = "txtcompany"
        Me.txtcompany.Size = New System.Drawing.Size(170, 28)
        Me.txtcompany.TabIndex = 2
        '
        'txtadesc
        '
        Me.txtadesc.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadesc.Location = New System.Drawing.Point(176, 172)
        Me.txtadesc.Multiline = True
        Me.txtadesc.Name = "txtadesc"
        Me.txtadesc.Size = New System.Drawing.Size(170, 53)
        Me.txtadesc.TabIndex = 3
        '
        'txtpname
        '
        Me.txtpname.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtpname.Location = New System.Drawing.Point(176, 104)
        Me.txtpname.Name = "txtpname"
        Me.txtpname.Size = New System.Drawing.Size(170, 28)
        Me.txtpname.TabIndex = 1
        '
        'lblcompany
        '
        Me.lblcompany.AutoSize = True
        Me.lblcompany.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcompany.Location = New System.Drawing.Point(12, 138)
        Me.lblcompany.Name = "lblcompany"
        Me.lblcompany.Size = New System.Drawing.Size(158, 21)
        Me.lblcompany.TabIndex = 15
        Me.lblcompany.Text = "COMPANY NAME"
        '
        'lblpname
        '
        Me.lblpname.AutoSize = True
        Me.lblpname.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblpname.Location = New System.Drawing.Point(12, 104)
        Me.lblpname.Name = "lblpname"
        Me.lblpname.Size = New System.Drawing.Size(114, 21)
        Me.lblpname.TabIndex = 14
        Me.lblpname.Text = "PART NAME"
        '
        'cbpid
        '
        Me.cbpid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbpid.FormattingEnabled = True
        Me.cbpid.Location = New System.Drawing.Point(176, 66)
        Me.cbpid.Name = "cbpid"
        Me.cbpid.Size = New System.Drawing.Size(119, 28)
        Me.cbpid.TabIndex = 0
        '
        'btnupdate
        '
        Me.btnupdate.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnupdate.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Location = New System.Drawing.Point(30, 236)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(119, 30)
        Me.btnupdate.TabIndex = 31
        Me.btnupdate.Text = "UPDATE"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnexit.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(167, 236)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(115, 30)
        Me.btnexit.TabIndex = 32
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(374, 127)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(493, 224)
        Me.DataGridView1.TabIndex = 30
        '
        'lblsearchid
        '
        Me.lblsearchid.AutoSize = True
        Me.lblsearchid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsearchid.Location = New System.Drawing.Point(395, 52)
        Me.lblsearchid.Name = "lblsearchid"
        Me.lblsearchid.Size = New System.Drawing.Size(137, 21)
        Me.lblsearchid.TabIndex = 33
        Me.lblsearchid.Text = "SEARCH BY ID"
        '
        'lbl_s_name
        '
        Me.lbl_s_name.AutoSize = True
        Me.lbl_s_name.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_s_name.Location = New System.Drawing.Point(608, 52)
        Me.lbl_s_name.Name = "lbl_s_name"
        Me.lbl_s_name.Size = New System.Drawing.Size(171, 21)
        Me.lbl_s_name.TabIndex = 34
        Me.lbl_s_name.Text = "SEARCH BY NAME"
        '
        'cbsearchid
        '
        Me.cbsearchid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbsearchid.FormattingEnabled = True
        Me.cbsearchid.Location = New System.Drawing.Point(399, 76)
        Me.cbsearchid.Name = "cbsearchid"
        Me.cbsearchid.Size = New System.Drawing.Size(119, 28)
        Me.cbsearchid.TabIndex = 0
        '
        'txt_s_name
        '
        Me.txt_s_name.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt_s_name.Location = New System.Drawing.Point(609, 76)
        Me.txt_s_name.Name = "txt_s_name"
        Me.txt_s_name.Size = New System.Drawing.Size(170, 28)
        Me.txt_s_name.TabIndex = 1
        '
        'btndel
        '
        Me.btndel.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btndel.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndel.Location = New System.Drawing.Point(30, 236)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(119, 30)
        Me.btndel.TabIndex = 39
        Me.btndel.Text = "DELETE"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'btnexit1
        '
        Me.btnexit1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnexit1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit1.Location = New System.Drawing.Point(167, 236)
        Me.btnexit1.Name = "btnexit1"
        Me.btnexit1.Size = New System.Drawing.Size(115, 30)
        Me.btnexit1.TabIndex = 40
        Me.btnexit1.Text = "EXIT"
        Me.btnexit1.UseVisualStyleBackColor = True
        '
        'lbldel
        '
        Me.lbldel.AutoSize = True
        Me.lbldel.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldel.Location = New System.Drawing.Point(92, 166)
        Me.lbldel.Name = "lbldel"
        Me.lbldel.Size = New System.Drawing.Size(115, 22)
        Me.lbldel.TabIndex = 38
        Me.lbldel.Text = "Delete By ID"
        '
        'cbpid1
        '
        Me.cbpid1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbpid1.FormattingEnabled = True
        Me.cbpid1.Location = New System.Drawing.Point(96, 202)
        Me.cbpid1.Name = "cbpid1"
        Me.cbpid1.Size = New System.Drawing.Size(119, 28)
        Me.cbpid1.TabIndex = 0
        '
        'lbldel1
        '
        Me.lbldel1.AutoSize = True
        Me.lbldel1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldel1.ForeColor = System.Drawing.Color.Red
        Me.lbldel1.Location = New System.Drawing.Point(274, 9)
        Me.lbldel1.Name = "lbldel1"
        Me.lbldel1.Size = New System.Drawing.Size(335, 26)
        Me.lbldel1.TabIndex = 41
        Me.lbldel1.Text = "AUTO PART DELETE  FORM"
        '
        'lblupdate
        '
        Me.lblupdate.AutoSize = True
        Me.lblupdate.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblupdate.ForeColor = System.Drawing.Color.Red
        Me.lblupdate.Location = New System.Drawing.Point(278, 9)
        Me.lblupdate.Name = "lblupdate"
        Me.lblupdate.Size = New System.Drawing.Size(340, 26)
        Me.lblupdate.TabIndex = 42
        Me.lblupdate.Text = "AUTO PART  UPDATE  FORM"
        '
        'lblsearch
        '
        Me.lblsearch.AutoSize = True
        Me.lblsearch.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblsearch.ForeColor = System.Drawing.Color.Red
        Me.lblsearch.Location = New System.Drawing.Point(274, 9)
        Me.lblsearch.Name = "lblsearch"
        Me.lblsearch.Size = New System.Drawing.Size(344, 26)
        Me.lblsearch.TabIndex = 43
        Me.lblsearch.Text = "AUTO PART  SEARCH  FORM"
        '
        'Aotop_Search_edit_del
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(879, 480)
        Me.Controls.Add(Me.lblsearch)
        Me.Controls.Add(Me.lblupdate)
        Me.Controls.Add(Me.lbldel1)
        Me.Controls.Add(Me.btndel)
        Me.Controls.Add(Me.btnexit1)
        Me.Controls.Add(Me.lbldel)
        Me.Controls.Add(Me.cbpid1)
        Me.Controls.Add(Me.cbsearchid)
        Me.Controls.Add(Me.txt_s_name)
        Me.Controls.Add(Me.lbl_s_name)
        Me.Controls.Add(Me.lblsearchid)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.cbpid)
        Me.Controls.Add(Me.lbladesc)
        Me.Controls.Add(Me.lblpid)
        Me.Controls.Add(Me.txtcompany)
        Me.Controls.Add(Me.txtadesc)
        Me.Controls.Add(Me.txtpname)
        Me.Controls.Add(Me.lblcompany)
        Me.Controls.Add(Me.lblpname)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Aotop_Search_edit_del"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Autop_Search_edit_del"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents lbladesc As System.Windows.Forms.Label
    Friend WithEvents lblpid As System.Windows.Forms.Label
    Friend WithEvents txtcompany As System.Windows.Forms.TextBox
    Friend WithEvents txtadesc As System.Windows.Forms.TextBox
    Friend WithEvents txtpname As System.Windows.Forms.TextBox
    Friend WithEvents lblcompany As System.Windows.Forms.Label
    Friend WithEvents lblpname As System.Windows.Forms.Label
    Friend WithEvents cbpid As System.Windows.Forms.ComboBox
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents lblsearchid As System.Windows.Forms.Label
    Friend WithEvents lbl_s_name As System.Windows.Forms.Label
    Friend WithEvents cbsearchid As System.Windows.Forms.ComboBox
    Friend WithEvents txt_s_name As System.Windows.Forms.TextBox
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents btnexit1 As System.Windows.Forms.Button
    Friend WithEvents lbldel As System.Windows.Forms.Label
    Friend WithEvents cbpid1 As System.Windows.Forms.ComboBox
    Friend WithEvents lbldel1 As System.Windows.Forms.Label
    Friend WithEvents lblupdate As System.Windows.Forms.Label
    Friend WithEvents lblsearch As System.Windows.Forms.Label
End Class
