﻿Imports System.Data
Imports System.Data.SqlClient

Public Class Login_Form

   
    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        If cbutype.Text = "" Then
            MsgBox("Select User Type")
            Exit Sub
        End If
        If txtuname.Text = "" Then
            MsgBox("Enter User Name")
            Exit Sub
        End If
        If txtpass.Text = "" Then
            MsgBox("Enter Password")
            Exit Sub
        End If
        Connection()
        strsql = "select utype, uname, upass from UserReg"
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If (dr.HasRows) Then
            While (dr.Read)
                'End While
                If dr(0).ToString = cbutype.Text Then
                    If dr(1).ToString = txtuname.Text Then
                        If dr(2).ToString = txtpass.Text Then
                            MsgBox("Login Successfully")
                            If dr(0).ToString = "Admin" Then
                                ut = 1
                            Else
                                ut = 0
                            End If
                            Auto_Mob_Shop.Show()
                            ' Me.Close()
                            txtuname.Clear()
                            txtpass.Clear()

                            Exit Sub
                        End If
                    End If
                End If
            End While
            MsgBox("Username or Password Not Match")
            txtpass.Clear()
            txtuname.Clear()
        End If
        Conclose()

    End Sub
    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub

    Private Sub Login_Form_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class