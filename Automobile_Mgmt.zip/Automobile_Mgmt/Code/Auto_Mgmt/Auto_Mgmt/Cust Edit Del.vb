﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Cust_Edit_Del
    Dim upass As String
    'FILL DATAGRID
    Public Sub Grid_Fill()
        Connection()
        strsql = "select cid As Cust_ID,cname As Name,cadd As Address,cmob As Mobile_No,regdate As Date,cgender As Gender,cemail As Email from CustReg"
        cmd = New SqlCommand(strsql, con)
        cmd.CommandType = CommandType.Text
        da = New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        Conclose()
    End Sub
    'CLEAR TEXTBOX
    Public Sub Clear()
        cbcustid.Text = ""
        cbcid.Text = ""
        cbcname.Text = ""
        txtcname.Text = ""
        txtcadd.Text = ""
        txtcmob.Text = ""
        txtemail.Text = ""
        'cbemail.Text = ""
    End Sub


    Private Sub Cust_Edit_Del_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Grid_Fill()
        'ACCESS ID
        Connection()
        strsql = "select cid,cname from CustReg"
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If (dr.HasRows) Then
            While (dr.Read)
                cbcid.Items.Add(dr(0).ToString())
                cbcustid.Items.Add(dr(0).ToString())
                cbcname.Items.Add(dr(1).ToString())
            End While
        End If
        Conclose()
        'update
        If mid = 0 Then
            Label1.Visible = False
            cbcid.Visible = False
            Label3.Visible = False
            cbcname.Visible = False
            btndel.Visible = False
            btnexit1.Visible = False
            lbldel.Visible = False
        End If
        If mid = 1 Then
            lblcid.Visible = False
            lblcname.Visible = False
            lblcadd.Visible = False
            lblcmob.Visible = False
            lblemail.Visible = False
            cbcustid.Visible = False
            txtcname.Visible = False
            txtcadd.Visible = False
            txtcmob.Visible = False
            txtemail.Visible = False
            btnupdate.Visible = False
            btnexit.Visible = False
            lblupdate.Visible = False
        End If
    End Sub

    'EXIT CODE
    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub
    'EXIT1 CODE
    Private Sub btnexit1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit1.Click
        Me.Close()
    End Sub
    'SEARCH CUST INFO
    Private Sub cbcustid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbcustid.SelectedIndexChanged
        If cbcustid.Text <> "" And IsNumeric(cbcustid.Text) Then
            Connection()
            strsql = "select * from CustReg where cid=" & cbcustid.Text
            cmd = New SqlCommand(strsql, con)
            dr = cmd.ExecuteReader
            If dr.HasRows Then
                While dr.Read
                    txtcname.Text = dr(1).ToString
                    txtcadd.Text = dr(2).ToString
                    txtcmob.Text = dr(3).ToString
                    txtemail.Text = dr(6).ToString
                End While

            Else
                MsgBox("Customer id information is not available")
            End If
            Conclose()
        Else
            MsgBox("Select Customer Id")
            Exit Sub
        End If
    End Sub

    'DELETE INFO BY ID OR NAME
    Private Sub btndel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btndel.Click
        If cbcid.Text <> "" And IsNumeric(cbcid.Text) Then
            Connection()
            strsql = "Delete from CustReg Where cid=" & cbcid.Text
            cmd = New SqlCommand(strsql, con)
            cmd.ExecuteNonQuery()
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            MsgBox("Customer Information Removed")
            Grid_Fill()
            Clear()
            Conclose()
        End If

        If cbcname.Text <> "" Then
            Connection()
            strsql = "Delete from CustReg Where cname like '%" & cbcname.Text & "%'"
            cmd = New SqlCommand(strsql, con)
            cmd.ExecuteNonQuery()
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            MsgBox("Customer Information Removed")
            Grid_Fill()
            Clear()
            Conclose()
       
            
        End If
    End Sub
    'SEARCH BY ID
    Private Sub cbcid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbcid.SelectedIndexChanged
        If cbcid.Text <> "" And IsNumeric(cbcid.Text) Then
            Connection()
            strsql = "select cid,cname,cadd,cmob,regdate,cgender,cemail  from CustReg  where cid= " & cbcid.Text
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            'Grid_Fill()
            'Clear()
            Conclose()

        End If
    End Sub
    'SEARCH BY NAME
    Private Sub cbcname_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbcname.SelectedIndexChanged
        If cbcname.Text <> "" Then
            Connection()
            strsql = "select cid,cname,cadd,cmob,regdate,cgender,cemail  from CustReg  where cname like '%" & cbcname.Text & "%'"
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            'Grid_Fill()
            'Clear()
            Conclose()
        End If
    End Sub

    'UPDATE CUST INFO
    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        If cbcustid.Text <> "" And IsNumeric(cbcustid.Text) Then
            Connection()
            strsql = "update CustReg set cname= '" & txtcname.Text & " ',cadd= '" & txtcadd.Text & "',cmob='" & txtcmob.Text & "',cemail= '" & txtemail.Text & "' where cid=" & cbcustid.Text
            cmd = New SqlCommand(strsql, con)
            cmd.ExecuteNonQuery()
            MsgBox("Customer Information Updated")
            Grid_Fill()
            Clear()
            Conclose()
        Else
            MsgBox("Select Customer Id")

        End If

    End Sub

    Private Sub cbcid_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbcid.GotFocus
        cbcname.Text = ""
        Grid_Fill()
    End Sub

    Private Sub cbcname_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles cbcname.GotFocus
        cbcid.Text = ""
        Grid_Fill()
    End Sub

End Class