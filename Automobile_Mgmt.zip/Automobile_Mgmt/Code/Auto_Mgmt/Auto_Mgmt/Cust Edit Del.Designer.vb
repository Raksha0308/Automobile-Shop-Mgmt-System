﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cust_Edit_Del
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.Label1 = New System.Windows.Forms.Label
        Me.cbcid = New System.Windows.Forms.ComboBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.btndel = New System.Windows.Forms.Button
        Me.btnexit1 = New System.Windows.Forms.Button
        Me.cbcname = New System.Windows.Forms.ComboBox
        Me.btnexit = New System.Windows.Forms.Button
        Me.btnupdate = New System.Windows.Forms.Button
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.lblemail = New System.Windows.Forms.Label
        Me.txtcmob = New System.Windows.Forms.TextBox
        Me.lblcmob = New System.Windows.Forms.Label
        Me.txtcadd = New System.Windows.Forms.TextBox
        Me.lblcadd = New System.Windows.Forms.Label
        Me.txtcname = New System.Windows.Forms.TextBox
        Me.lblcname = New System.Windows.Forms.Label
        Me.cbcustid = New System.Windows.Forms.ComboBox
        Me.lblcid = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.lblupdate = New System.Windows.Forms.Label
        Me.lbldel = New System.Windows.Forms.Label
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(316, 110)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 24
        Me.DataGridView1.Size = New System.Drawing.Size(530, 224)
        Me.DataGridView1.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(124, 180)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(115, 22)
        Me.Label1.TabIndex = 34
        Me.Label1.Text = "Delete By ID"
        '
        'cbcid
        '
        Me.cbcid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbcid.FormattingEnabled = True
        Me.cbcid.Location = New System.Drawing.Point(128, 208)
        Me.cbcid.Name = "cbcid"
        Me.cbcid.Size = New System.Drawing.Size(119, 28)
        Me.cbcid.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(114, 245)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(142, 22)
        Me.Label3.TabIndex = 31
        Me.Label3.Text = "Delete By Name"
        '
        'btndel
        '
        Me.btndel.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btndel.Location = New System.Drawing.Point(61, 304)
        Me.btndel.Name = "btndel"
        Me.btndel.Size = New System.Drawing.Size(119, 30)
        Me.btndel.TabIndex = 35
        Me.btndel.Text = "DELETE"
        Me.btndel.UseVisualStyleBackColor = True
        '
        'btnexit1
        '
        Me.btnexit1.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit1.Location = New System.Drawing.Point(195, 304)
        Me.btnexit1.Name = "btnexit1"
        Me.btnexit1.Size = New System.Drawing.Size(115, 30)
        Me.btnexit1.TabIndex = 36
        Me.btnexit1.Text = "EXIT"
        Me.btnexit1.UseVisualStyleBackColor = True
        '
        'cbcname
        '
        Me.cbcname.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbcname.FormattingEnabled = True
        Me.cbcname.Location = New System.Drawing.Point(109, 270)
        Me.cbcname.Name = "cbcname"
        Me.cbcname.Size = New System.Drawing.Size(147, 28)
        Me.cbcname.TabIndex = 1
        '
        'btnexit
        '
        Me.btnexit.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnexit.Location = New System.Drawing.Point(195, 304)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(115, 30)
        Me.btnexit.TabIndex = 6
        Me.btnexit.Text = "EXIT"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'btnupdate
        '
        Me.btnupdate.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnupdate.Location = New System.Drawing.Point(61, 304)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(119, 30)
        Me.btnupdate.TabIndex = 5
        Me.btnupdate.Text = "UPDATE"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'txtemail
        '
        Me.txtemail.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtemail.Location = New System.Drawing.Point(128, 263)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(171, 28)
        Me.txtemail.TabIndex = 4
        '
        'lblemail
        '
        Me.lblemail.AutoSize = True
        Me.lblemail.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblemail.Location = New System.Drawing.Point(12, 263)
        Me.lblemail.Name = "lblemail"
        Me.lblemail.Size = New System.Drawing.Size(67, 21)
        Me.lblemail.TabIndex = 21
        Me.lblemail.Text = "EMAIL"
        '
        'txtcmob
        '
        Me.txtcmob.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcmob.Location = New System.Drawing.Point(128, 225)
        Me.txtcmob.MaxLength = 10
        Me.txtcmob.Name = "txtcmob"
        Me.txtcmob.Size = New System.Drawing.Size(171, 28)
        Me.txtcmob.TabIndex = 3
        '
        'lblcmob
        '
        Me.lblcmob.AutoSize = True
        Me.lblcmob.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcmob.Location = New System.Drawing.Point(12, 228)
        Me.lblcmob.Name = "lblcmob"
        Me.lblcmob.Size = New System.Drawing.Size(117, 21)
        Me.lblcmob.TabIndex = 19
        Me.lblcmob.Text = "MOBILE NO."
        '
        'txtcadd
        '
        Me.txtcadd.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcadd.Location = New System.Drawing.Point(128, 172)
        Me.txtcadd.Multiline = True
        Me.txtcadd.Name = "txtcadd"
        Me.txtcadd.Size = New System.Drawing.Size(171, 47)
        Me.txtcadd.TabIndex = 2
        '
        'lblcadd
        '
        Me.lblcadd.AutoSize = True
        Me.lblcadd.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcadd.Location = New System.Drawing.Point(12, 175)
        Me.lblcadd.Name = "lblcadd"
        Me.lblcadd.Size = New System.Drawing.Size(95, 21)
        Me.lblcadd.TabIndex = 20
        Me.lblcadd.Text = "ADDRESS"
        '
        'txtcname
        '
        Me.txtcname.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtcname.Location = New System.Drawing.Point(128, 131)
        Me.txtcname.Name = "txtcname"
        Me.txtcname.Size = New System.Drawing.Size(171, 28)
        Me.txtcname.TabIndex = 1
        '
        'lblcname
        '
        Me.lblcname.AutoSize = True
        Me.lblcname.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcname.Location = New System.Drawing.Point(12, 138)
        Me.lblcname.Name = "lblcname"
        Me.lblcname.Size = New System.Drawing.Size(63, 21)
        Me.lblcname.TabIndex = 18
        Me.lblcname.Text = "NAME"
        '
        'cbcustid
        '
        Me.cbcustid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbcustid.FormattingEnabled = True
        Me.cbcustid.Location = New System.Drawing.Point(128, 93)
        Me.cbcustid.Name = "cbcustid"
        Me.cbcustid.Size = New System.Drawing.Size(119, 28)
        Me.cbcustid.TabIndex = 0
        '
        'lblcid
        '
        Me.lblcid.AutoSize = True
        Me.lblcid.Font = New System.Drawing.Font("Times New Roman", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblcid.Location = New System.Drawing.Point(16, 93)
        Me.lblcid.Name = "lblcid"
        Me.lblcid.Size = New System.Drawing.Size(29, 21)
        Me.lblcid.TabIndex = 29
        Me.lblcid.Text = "ID"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Auto_Mgmt.My.Resources.Resources.backimg2
        Me.PictureBox1.Location = New System.Drawing.Point(0, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(878, 469)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'lblupdate
        '
        Me.lblupdate.AutoSize = True
        Me.lblupdate.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblupdate.ForeColor = System.Drawing.Color.Red
        Me.lblupdate.Location = New System.Drawing.Point(303, 32)
        Me.lblupdate.Name = "lblupdate"
        Me.lblupdate.Size = New System.Drawing.Size(330, 26)
        Me.lblupdate.TabIndex = 37
        Me.lblupdate.Text = "CUSTOMER UPDATE FORM"
        '
        'lbldel
        '
        Me.lbldel.AutoSize = True
        Me.lbldel.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbldel.ForeColor = System.Drawing.Color.Red
        Me.lbldel.Location = New System.Drawing.Point(303, 32)
        Me.lbldel.Name = "lbldel"
        Me.lbldel.Size = New System.Drawing.Size(337, 26)
        Me.lbldel.TabIndex = 38
        Me.lbldel.Text = "CUSTOMER DELETE  FORM"
        '
        'Cust_Edit_Del
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(879, 480)
        Me.Controls.Add(Me.lbldel)
        Me.Controls.Add(Me.lblupdate)
        Me.Controls.Add(Me.cbcustid)
        Me.Controls.Add(Me.cbcname)
        Me.Controls.Add(Me.btndel)
        Me.Controls.Add(Me.btnexit1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cbcid)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.lblcid)
        Me.Controls.Add(Me.txtcmob)
        Me.Controls.Add(Me.txtemail)
        Me.Controls.Add(Me.btnexit)
        Me.Controls.Add(Me.txtcname)
        Me.Controls.Add(Me.txtcadd)
        Me.Controls.Add(Me.lblemail)
        Me.Controls.Add(Me.lblcadd)
        Me.Controls.Add(Me.lblcmob)
        Me.Controls.Add(Me.lblcname)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Cust_Edit_Del"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Cust_Edit_Del"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cbcid As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btndel As System.Windows.Forms.Button
    Friend WithEvents btnexit1 As System.Windows.Forms.Button
    Friend WithEvents cbcname As System.Windows.Forms.ComboBox
    Friend WithEvents btnexit As System.Windows.Forms.Button
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents lblemail As System.Windows.Forms.Label
    Friend WithEvents txtcmob As System.Windows.Forms.TextBox
    Friend WithEvents lblcmob As System.Windows.Forms.Label
    Friend WithEvents txtcadd As System.Windows.Forms.TextBox
    Friend WithEvents lblcadd As System.Windows.Forms.Label
    Friend WithEvents txtcname As System.Windows.Forms.TextBox
    Friend WithEvents lblcname As System.Windows.Forms.Label
    Friend WithEvents cbcustid As System.Windows.Forms.ComboBox
    Friend WithEvents lblcid As System.Windows.Forms.Label
    Friend WithEvents lblupdate As System.Windows.Forms.Label
    Friend WithEvents lbldel As System.Windows.Forms.Label
End Class
