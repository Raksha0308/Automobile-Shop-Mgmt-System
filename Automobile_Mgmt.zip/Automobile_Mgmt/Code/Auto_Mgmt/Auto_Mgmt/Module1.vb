﻿Imports System.Data
Imports System.Data.SqlClient
Module Module1
    Public con As SqlConnection
    Public cmd As SqlCommand
    Public dr As SqlDataReader
    Public da As SqlDataAdapter
    Public ds As DataSet
    Public strcon As String
    Public strsql As String
    Public ut As Integer
    Public mid As Integer
    Public Billno As Integer
   

    Sub Connection()
        strcon = "Data Source=Sainash-PC;Initial Catalog=Auto_DB;Persist Security Info=True;User ID=sa;Password=123"
        con = New SqlConnection(strcon)
        con.Open()
    End Sub
    Sub Conclose()
        con.Close()
    End Sub


End Module
