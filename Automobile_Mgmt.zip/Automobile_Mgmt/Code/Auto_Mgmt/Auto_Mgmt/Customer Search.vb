﻿Imports System.Data
Imports System.Data.SqlClient
Public Class Customer_Search
    Private Sub Customer_Search_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'FILL DATAGRID
        Connection()
        strsql = "select cid,cname,cadd,cmob,regdate,cgender,cemail from CustReg"
        cmd = New SqlCommand(strsql, con)
        cmd.CommandType = CommandType.Text
        da = New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)
        DataGridView1.DataSource = ds.Tables(0)
        DataGridView2.DataSource = ds.Tables(0)
        Conclose()
        Connection()
        'ACCESS ID
        strsql = "select cid from CustReg"
        cmd = New SqlCommand(strsql, con)
        dr = cmd.ExecuteReader
        If (dr.HasRows) Then
            While (dr.Read)
                cbcid.Items.Add(dr(0).ToString())
            End While
        End If
        Conclose()
        rbtsearchid.Checked = True
        txtcname.Enabled = False
    End Sub

    Private Sub txtcname_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcname.TextChanged
        If txtcname.Text <> "" Then
            Connection()
            strsql = "select cid,cname,cadd,cmob,regdate,cgender,cemail  from CustReg where cname like '%" & txtcname.Text & "%'"
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            Conclose()
        End If
    End Sub

    Private Sub cbcid_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbcid.SelectedIndexChanged
        If cbcid.Text <> "" And IsNumeric(cbcid.Text) Then
            Connection()
            strsql = "select cid,cname,cadd,cmob,regdate,cgender,cemail  from CustReg  where cid= " & cbcid.Text
            cmd = New SqlCommand(strsql, con)
            cmd.CommandType = CommandType.Text
            da = New SqlDataAdapter(cmd)
            Dim ds As New DataSet
            da.Fill(ds)
            DataGridView1.DataSource = ds.Tables(0)
            Conclose()
        End If
    End Sub

    Private Sub rbtsearchid_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtsearchid.CheckedChanged
        If rbtsearchid.Checked = True Then
            txtcname.Enabled = False
            '     Else
            '   txtcname.Enabled = True
            txtcname.Text = ""
            cbcid.Enabled = True
        End If
    End Sub

    Private Sub rbtsearchname_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbtsearchname.CheckedChanged
        If rbtsearchname.Checked = True Then
            cbcid.Enabled = False
            cbcid.Text = ""
            '  Else
            '  cbcid.Enabled = True
            txtcname.Enabled = True
            txtcname.Text = ""
        End If
    End Sub
End Class