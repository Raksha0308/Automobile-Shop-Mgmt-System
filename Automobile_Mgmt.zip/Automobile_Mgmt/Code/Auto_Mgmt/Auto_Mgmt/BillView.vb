﻿Imports System.Data
Imports System.Data.SqlClient
Imports CrystalDecisions.CrystalReports.Engine
Imports CrystalDecisions.Shared
Public Class BillView

    Private Sub BillView_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cryRpt As New ReportDocument
        cryRpt.Load("D:\Auto_Mgmt\Code\Auto_Mgmt\Auto_Mgmt\BillGenerate2.rpt")
        Dim crs As ParameterFieldDefinitions
        Dim cr As ParameterFieldDefinition
        Dim Pr As New ParameterValues
        Dim Prd As New ParameterDiscreteValue
        Prd.Value = Billno
        crs = cryRpt.DataDefinition.ParameterFields
        cr = crs("@slid")
        Pr = cr.CurrentValues
        Pr.Add(Prd)
        cr.ApplyCurrentValues(Pr)
        CrystalReportViewer1.ReportSource = cryRpt
        CrystalReportViewer1.Refresh()
    End Sub
End Class